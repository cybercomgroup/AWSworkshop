import RPi.GPIO as GPIO
import time

useWebsocket = False
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(17, GPIO.OUT)
GPIO.setup(18, GPIO.OUT)

def lampon(msg):
        if msg == "create":
                blink(17)
        elif msg == "delete":
                blink(18)
        else:
                GPIO.output(18, GPIO.LOW)
                GPIO.output(17, GPIO.LOW)

def blink(pinnumber):
        i = 0;
        while i < 20:
                i += 1
                GPIO.output(pinnumber, GPIO.HIGH)
                time.sleep(0.03)
                GPIO.output(pinnumber, GPIO.LOW)
                time.sleep(0.03)

count = 0
while count < 2:
        count += 1

        if count == 1:
                lampon("create")
        if count == 2:
                lampon("delete")
        time.sleep(3)
