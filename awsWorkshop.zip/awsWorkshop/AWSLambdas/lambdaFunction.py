import boto3
import json

def lambda_handler(event, context):

    client = boto3.client('iot-data', region_name='eu-west-1')

    eventName = json.dumps(event['Records'][0]['eventName'])

    ledAction = ""

    if eventName == "\"ObjectRemoved:Delete\"":
        ledAction = "delete"
    elif eventName == "\"ObjectCreated:Put\"":
        ledAction = "create"

    response = client.publish(
        topic = '',
        qos = 1,
        payload = ledAction
    )
